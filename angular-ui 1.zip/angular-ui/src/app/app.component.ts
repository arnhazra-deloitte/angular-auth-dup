import { Component, ViewChild, ElementRef } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AppHeaderComponent } from './app-header/app-header.component';
import * as XLSX from 'xlsx';
import { VALIDATION_TYPE, MARKETS, TABLE_HEADERS } from './constants/index';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule, FormsModule, AppHeaderComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  @ViewChild('fileInput1') fileInput1!: ElementRef;
  @ViewChild('fileInput2') fileInput2!: ElementRef;

  selectedMode: string = VALIDATION_TYPE.AUTHORISATION;
  selectedMarket: string = MARKETS.CSBD;

  headers1: string[] = [];
  data1: string[][] = [];

  showTable1: boolean = false;
  showTable2: boolean = false;

  headers2: string[] = [];
  data2: string[][] = [];

  isSubmitted: boolean = false;

  selectedFile1: File | null = null;
  selectedFile2: File | null = null;

  generate() {
    this.showTable1 = true;
    this.showTable2 = true;
  }

  clear() {
    this.fileInput1.nativeElement.value = '';
    this.fileInput2.nativeElement.value = '';
    this.headers1 = [];
    this.headers2 = [];
    this.data1 = [];
    this.data2 = [];
    this.selectedFile1 = null;
    this.selectedFile2 = null;
  }

  onFileChange1(event: Event) {
    const target = event.target as HTMLInputElement;

    if (!target.files || target.files.length !== 1) {
      return;
    }
    const file: File = target.files[0];
    this.selectedFile1 = target.files[0];
    const reader: FileReader = new FileReader();

    reader.onload = (e: ProgressEvent<FileReader>) => {
      const binaryStr = e.target?.result as string;
      const workbook: XLSX.WorkBook = XLSX.read(binaryStr, { type: 'binary' });

      const sheetName: string = workbook.SheetNames[0];
      const sheet: XLSX.WorkSheet = workbook.Sheets[sheetName];

      const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

      if (jsonData.length > 0) {
        let headersArray1 = jsonData[0] as string[];
        this.headers1 = headersArray1.filter((h) =>
          TABLE_HEADERS[this.selectedMode][this.selectedMarket][0].includes(h)
        );
        this.data1 = jsonData
          .slice(1)
          .map((r: any) => r.map((cell: any) => String(cell)));

        for (let i = 0; i < this.data1.length; i++) {
          this.data1[i] = this.data1[i].filter((_d: any, index: number) => {
            return TABLE_HEADERS[this.selectedMode][
              this.selectedMarket
            ][0].includes(headersArray1[index]);
          });
        }
      }
    };

    reader.readAsBinaryString(file);
  }

  onFileChange2(event: Event) {
    const target = event.target as HTMLInputElement;

    if (!target.files || target.files.length !== 1) {
      return;
    }
    const file: File = target.files[0];
    this.selectedFile2 = target.files[0];
    const reader: FileReader = new FileReader();

    reader.onload = (e: ProgressEvent<FileReader>) => {
      const binaryStr = e.target?.result as string;
      const workbook: XLSX.WorkBook = XLSX.read(binaryStr, { type: 'binary' });

      const sheetName: string = workbook.SheetNames[0];
      const sheet: XLSX.WorkSheet = workbook.Sheets[sheetName];

      const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });
      if (jsonData.length > 0) {
        let headersArray2 = jsonData[0] as string[];
        this.headers2 = headersArray2.filter((h) =>
          TABLE_HEADERS[this.selectedMode][this.selectedMarket][1].includes(h)
        );
        this.data2 = jsonData
          .slice(1)
          .map((r: any) => r.map((cell: any) => String(cell)));

        for (let i = 0; i < this.data2.length; i++) {
          this.data2[i] = this.data2[i].filter((_d: any, index: number) => {
            return TABLE_HEADERS[this.selectedMode][
              this.selectedMarket
            ][1].includes(headersArray2[index]);
          });
        }
      }
    };

    reader.readAsBinaryString(file);
  }

  submit() {
    // Handle integrations
  }
}
