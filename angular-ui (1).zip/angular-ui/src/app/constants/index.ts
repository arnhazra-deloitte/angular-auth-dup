export const MARKETS = {
  CSBD: 'CSBD',
  GBD: 'GBD',
};

export const VALIDATION_TYPE = {
  AUTHORISATION: 'Authorisation',
  DUPLICATES: 'Duplicates',
};

export const TABLE_HEADERS = {
  [VALIDATION_TYPE.AUTHORISATION]: {
    [MARKETS.CSBD]: [
      [
        'CLM_DCN',
        'CERT_NBR',
        'CLM_PRVDR_TAX_ID',
        'CLM_RENDERING_NPI',
        'LNE_SVC_FRM_DTE',
        'LNE_SVC_THRU_DTE',
        'LNE_PRCDR_CDE',
      ],
      ['UM_REC#', 'UM_STRT_DT', 'UM_END_DT', 'PROC_CD'],
    ],
    [MARKETS.GBD]: [['CLCL_ID', 'MEME_CK', 'IPCD_ID']],
  },
  [VALIDATION_TYPE.DUPLICATES]: {
    [MARKETS.CSBD]: [
      ['CLM_DCN', 'CLM_PAT_MBR_CDE', 'CLM_CD_TAX_ID', 'CLM_RNDR_NPI'],
      ['LNE_DOS_FROM', 'LNE_DOS_THRU', 'LNE_PRCDR_CDE', 'LNE_UNTS_OCCUR'],
    ],
    [MARKETS.GBD]: [[], []],
  },
};
